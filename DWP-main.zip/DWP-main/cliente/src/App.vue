<script setup>
</script>

<template>
  <!-- Router view base -->
  <router-view/>
</template>

<style scoped>
</style>
