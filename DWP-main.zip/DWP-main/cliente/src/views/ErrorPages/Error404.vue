<template>
  <div>
    <h1>404 - Página no encontrada</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>